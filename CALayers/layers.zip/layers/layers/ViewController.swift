//
//  ViewController.swift
//  layers
//
//  Created by Pranjal Satija on 5/14/16.
//  Copyright © 2016 Pranjal Satija. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet private var box: UIView!
    
    override func viewDidLoad() {
        box.layer.cornerRadius = 30.0
        
        //Adding shadow effect
        box.layer.shadowOffset = CGSize(width: 20.0, height: 5.0)
        box.layer.shadowOpacity = 0.7
        box.layer.shadowRadius = 5
        box.layer.shadowColor = UIColor(red: 44.0/255.0, green: 62.0/255.0, blue: 80.0/255.0, alpha: 1.0).cgColor
        
        //Applying Borders
        box.layer.borderColor = UIColor.blue.cgColor
        box.layer.borderWidth = 3
        
        //Displaying Images
        box.layer.contents = UIImage(named: "tree.jpg")?.cgImage
        box.layer.contentsGravity = kCAGravityResize
        box.layer.masksToBounds = true
        
        //Background color and opacity
        box.layer.backgroundColor = UIColor.blue.cgColor
        box.layer.opacity = 0.5
    }
}
